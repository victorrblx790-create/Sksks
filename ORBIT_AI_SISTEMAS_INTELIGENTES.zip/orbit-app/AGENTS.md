# Orientações para agentes de código
- Use o dossiê ORBIT como contexto principal e preserve decisões existentes.
- Mantenha o visual premium minimalista branco/preto; use Lucide React para ícones.
- Nunca exponha `DIFY_API_KEY` no navegador, em variáveis `VITE_*` ou no Git.
- Não invente que testes, build ou deploy foram executados; rode os comandos e reporte os resultados reais.
- Não implemente publicação automática, envio de mensagens externas ou ações irreversíveis sem confirmação humana explícita.
- Antes de produção, adicionar autenticação, autorização por proprietário, rate limiting, validação, política de privacidade e termos.
