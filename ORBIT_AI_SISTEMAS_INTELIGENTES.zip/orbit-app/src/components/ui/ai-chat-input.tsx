import * as React from 'react';
import { ArrowUp, Mic, Plus, Sparkles, X, Image as ImageIcon, FileText } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface PromptInputProps {
  onSubmit?: (value: string, meta: { model: string; effort: string; attachments: File[] }) => void;
  placeholder?: string;
  className?: string;
  models?: string[];
  efforts?: string[];
  defaultValue?: string;
  value?: string;
  onChange?: (value: string) => void;
  maxAttachments?: number;
  disabled?: boolean;
  sending?: boolean;
  onToolsClick?: () => void;
  onImprovePrompt?: () => void;
}

/** ORBIT's chat composer. Works with controlled or uncontrolled text values. */
export const PromptInput = React.forwardRef<HTMLDivElement, PromptInputProps>(function PromptInput(
  { onSubmit, placeholder = 'Pergunte qualquer coisa ao ORBIT...', className, models = ['ORBIT AI'], efforts = ['Padrão', 'Mais elaborado'], defaultValue = '', value: controlledValue, onChange, maxAttachments = 6, disabled = false, sending = false, onToolsClick, onImprovePrompt }, ref,
) {
  const [localValue, setLocalValue] = React.useState(defaultValue);
  const [model, setModel] = React.useState(models[0] ?? 'ORBIT AI');
  const [effort, setEffort] = React.useState(efforts[0] ?? 'Padrão');
  const [attachments, setAttachments] = React.useState<File[]>([]);
  const [recording, setRecording] = React.useState(false);
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);
  const fileRef = React.useRef<HTMLInputElement>(null);
  const currentValue = controlledValue === undefined ? localValue : controlledValue;

  React.useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  }, [currentValue]);
  React.useEffect(() => () => attachments.forEach(file => { /* File URLs are not created by this component. */ void file; }), [attachments]);

  const updateValue = (next: string) => {
    if (controlledValue === undefined) setLocalValue(next);
    onChange?.(next);
  };
  const submit = () => {
    if (disabled || sending || (!currentValue.trim() && attachments.length === 0)) return;
    onSubmit?.(currentValue.trim(), { model, effort, attachments });
    if (controlledValue === undefined) setLocalValue('');
    onChange?.('');
    setAttachments([]);
  };
  const addFiles = (files: FileList | null) => {
    if (!files) return;
    setAttachments(prev => [...prev, ...Array.from(files)].slice(0, maxAttachments));
  };

  return <div ref={ref} className={cn('orbit-prompt-input', className)}>
    {attachments.length > 0 && <div className="orbit-attachment-list">{attachments.map((file, i) => <div className="orbit-attachment" key={`${file.name}-${file.lastModified}-${i}`}><span className="orbit-attachment-icon">{file.type.startsWith('image/') ? <ImageIcon size={15}/> : <FileText size={15}/>}</span><span className="orbit-attachment-name">{file.name}</span><button type="button" aria-label={`Remover ${file.name}`} onClick={() => setAttachments(prev => prev.filter((_, index) => index !== i))}><X size={13}/></button></div>)}</div>}
    <textarea ref={textareaRef} value={currentValue} onChange={e => updateValue(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); } }} placeholder={placeholder} rows={1} aria-label="Mensagem para o ORBIT" disabled={disabled} />
    <input ref={fileRef} type="file" hidden multiple accept="image/*,.pdf,.txt,.doc,.docx,.csv" onChange={e => { addFiles(e.target.files); e.currentTarget.value = ''; }} />
    <div className="orbit-prompt-footer">
      <div className="orbit-prompt-tools">
        <button type="button" onClick={() => fileRef.current?.click()} disabled={disabled || attachments.length >= maxAttachments}><Plus size={15}/> Anexar</button>
        {onToolsClick && <button type="button" onClick={onToolsClick}><Sparkles size={14}/> Ferramentas</button>}
        {onImprovePrompt && <button type="button" onClick={onImprovePrompt}><Sparkles size={14}/> Melhorar prompt</button>}
        <select aria-label="Modelo" value={model} onChange={e => setModel(e.target.value)}>{models.map(m => <option key={m} value={m}>{m}</option>)}</select>
        <select aria-label="Nível de resposta" value={effort} onChange={e => setEffort(e.target.value)}>{efforts.map(x => <option key={x} value={x}>{x}</option>)}</select>
      </div>
      <div className="orbit-prompt-submit">
        <button type="button" className={`orbit-mic ${recording ? 'recording' : ''}`} aria-label={recording ? 'Parar gravação de voz' : 'Entrada por voz'} onClick={() => { setRecording(v => !v); if (!recording && !('SpeechRecognition' in window) && !('webkitSpeechRecognition' in window)) alert('A entrada por voz não é compatível com este navegador.'); }}><Mic size={16}/></button>
        <button type="button" className="orbit-send" disabled={disabled || sending || (!currentValue.trim() && attachments.length === 0)} onClick={submit} aria-label="Enviar mensagem">{sending ? <span className="orbit-send-spinner"/> : <ArrowUp size={18}/>}</button>
      </div>
    </div>
    <div className="orbit-prompt-hint">Enter para enviar · Shift + Enter para nova linha</div>
  </div>;
});
PromptInput.displayName = 'PromptInput';
