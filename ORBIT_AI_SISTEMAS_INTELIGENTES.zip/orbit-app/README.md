# ORBIT AI — MVP

Interface web em React + TypeScript, com identidade branco/preto, ícones Lucide, conversas e projetos salvos localmente, gerador de conteúdo e backend Express preparado para o Dify.

## Requisitos
- Node.js 20 ou superior (Node 22 recomendado)
- npm
- Chave de API do aplicativo Dify para ativar respostas reais

## Instalação
```bash
npm install
cp .env.example .env
```
Edite `.env` e configure `DIFY_API_KEY` com a chave secreta do aplicativo Dify. Nunca coloque essa chave no frontend nem a publique em repositórios.

## Executar localmente
```bash
npm run dev
```
- Frontend: `http://localhost:5173`
- API: `http://localhost:8787/api/health`

O Vite encaminha `/api` ao backend local na porta 8787. Em ambientes remotos (por exemplo, IDEs no navegador), certifique-se de que as duas tarefas estejam rodando e que o encaminhamento de portas esteja configurado. Se só o frontend estiver publicado, o chat não conseguirá responder.

## Verificação
```bash
npm run typecheck
npm run build
```

## Limites atuais
Este é um MVP, não uma aplicação pronta para produção. Conversas e projetos ficam no navegador; ainda faltam autenticação, banco de dados remoto, autorização por usuário, limites de uso, política de privacidade e termos.

## Componente de entrada de chat

O componente reutilizável está em `src/components/ui/ai-chat-input.tsx` e usa TypeScript + React + `lucide-react`. A pasta `src/components/ui` segue a convenção de componentes de interface usada pelo shadcn/ui. O projeto atual ainda usa CSS próprio em `src/styles.css`, não Tailwind/shadcn; o componente foi adaptado ao CSS existente para não exigir uma migração de estilos que poderia quebrar as telas.

Para adotar shadcn/ui/Tailwind oficialmente no projeto no futuro, configure primeiro os aliases `@/*` no `tsconfig.json` e no Vite, depois execute `npx shadcn@latest init` seguindo as instruções da CLI. Mantenha componentes compartilhados em `src/components/ui` para centralizar os componentes básicos e facilitar manutenção e importações consistentes.
