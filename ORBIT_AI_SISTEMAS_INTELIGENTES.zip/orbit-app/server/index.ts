import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { z } from 'zod';

const app = express();
const port = Number(process.env.PORT || 8787);
const baseUrl = (process.env.DIFY_BASE_URL || 'https://api.dify.ai/v1').replace(/\/$/, '');
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || ['http://localhost:5173', 'http://127.0.0.1:5173'] }));
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (_req, res) => res.status(200).json({ ok: true, provider: 'dify', configured: Boolean(process.env.DIFY_API_KEY), app: 'ORBIT' }));

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Erro na API ORBIT:', err instanceof Error ? err.message : 'erro desconhecido');
  if (!res.headersSent) res.status(500).json({ error: 'O servidor ORBIT encontrou um erro interno. Confira o terminal do backend.' });
});

const chatSchema = z.object({
  query: z.string().trim().min(1).max(12000),
  conversation_id: z.string().max(200).optional().default(''),
  user: z.string().trim().min(1).max(100).regex(/^[a-zA-Z0-9_-]+$/).default('orbit-guest'),
  inputs: z.record(z.unknown()).optional().default({}),
});

app.post('/api/chat', async (req, res) => {
  const parsed = chatSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Mensagem inválida. Confira o texto e tente novamente.' });
  const key = process.env.DIFY_API_KEY;
  if (!key || key === 'cole_aqui_a_chave_secreta_do_app_no_Dify') {
    return res.status(503).json({ error: 'O ORBIT ainda não está conectado ao Dify. Configure DIFY_API_KEY no arquivo .env do servidor. Não cole essa chave no frontend.' });
  }
  try {
    const upstream = await fetch(`${baseUrl}/chat-messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ inputs: parsed.data.inputs, query: parsed.data.query, response_mode: 'blocking', conversation_id: parsed.data.conversation_id, user: parsed.data.user }),
      signal: AbortSignal.timeout(60000),
    });
    const data: any = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const message = upstream.status === 401 || upstream.status === 403 ? 'O Dify recusou a chave. Confira se você usou a chave de API do aplicativo, e não o ID do app.' : (data.message || data.error || `O Dify respondeu com status ${upstream.status}.`);
      return res.status(upstream.status >= 500 ? 502 : upstream.status).json({ error: message });
    }
    return res.json({ answer: data.answer || '', conversation_id: data.conversation_id || '', message_id: data.message_id || '' });
  } catch (error) {
    const message = error instanceof Error && error.name === 'TimeoutError' ? 'O Dify demorou demais para responder. Tente novamente.' : 'Não foi possível alcançar o Dify. Verifique a conexão e a URL.';
    return res.status(502).json({ error: message });
  }
});

app.listen(port, () => console.log(`ORBIT API disponível em http://localhost:${port}`));
